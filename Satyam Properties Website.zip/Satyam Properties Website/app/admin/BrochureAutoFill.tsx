'use client';
import { useState } from 'react';
import { parseBrochureText } from '../lib/brochure-parser';

export default function BrochureAutoFill({existingBrochure}:{existingBrochure?:string}) {
  const [status,setStatus]=useState('');
  async function extract(event:React.ChangeEvent<HTMLInputElement>) {
    const file=event.target.files?.[0]; if(!file)return;
    let result:Record<string,any>;
    if (file.type.startsWith('image/')) {
      setStatus('Starting image text recognition…');
      try {
        const {createWorker}=await import('tesseract.js');
        const worker=await createWorker('eng',1,{logger:(message)=>{if(message.status==='recognizing text')setStatus(`Reading image text… ${Math.round((message.progress||0)*100)}%`);}});
        const recognized=await worker.recognize(file); await worker.terminate();
        result=parseBrochureText(recognized.data.text,1);
      } catch { setStatus('Could not read this image. Try a clearer, straight image with larger text.'); return; }
    } else {
      setStatus('Reading PDF brochure and filling details…');
      const data=new FormData(); data.set('brochure',file);
      const response=await fetch('/api/admin/brochure-extract',{method:'POST',body:data});
      result=await response.json().catch(()=>({error:'Could not read brochure.'}));
      if(!response.ok){setStatus(result.error||'Could not read brochure.');return;}
    }
    const form=event.target.form; if(!form)return;
    const fill=(name:string,value:string)=>{if(!value)return;const field=form.elements.namedItem(name) as HTMLInputElement|HTMLTextAreaElement|HTMLSelectElement|null;if(field)field.value=value;};
    fill('title',result.title);fill('type',result.type);fill('location',result.location);fill('size',result.size);fill('price',result.price);fill('note',result.note);fill('highlights',result.highlights);
    setStatus(`Details recognized and filled. Please review every field before saving.`);
  }
  return <><input type="hidden" name="existingBrochure" value={existingBrochure||''}/><label className="brochure-upload">Property brochure (PDF or image)<input type="file" name="brochure" accept="application/pdf,.pdf,image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp" onChange={extract}/><small>{status|| (existingBrochure?'A brochure is attached. Choose a new PDF or image to replace and re-read it.':'PDF and image text auto-fills details · Maximum 15 MB')}</small></label></>;
}
