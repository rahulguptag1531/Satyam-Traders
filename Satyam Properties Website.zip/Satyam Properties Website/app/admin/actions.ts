'use server';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '../chatgpt-auth';
import { saveProperty, updateEnquiryStatus } from '../../db';

export async function savePropertyAction(data:FormData) {
  if (!await requireAdmin()) throw new Error('Unauthorized');
  const value=(key:string)=>String(data.get(key)||'').trim();
  const title=value('title'); const slug=(value('slug') || title).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'');
  if (!title || !slug) throw new Error('Title is required');
  await saveProperty({slug,title,type:value('type'),location:value('location'),size:value('size'),price:value('price'),note:value('note'),image:value('image')||'/demo-wathoda-plot.webp',highlights:value('highlights').split(',').map(v=>v.trim()).filter(Boolean),status:value('status')||'live'});
  revalidatePath('/admin'); revalidatePath('/');
}
export async function updateLeadAction(data:FormData) {
  if (!await requireAdmin()) throw new Error('Unauthorized');
  await updateEnquiryStatus(String(data.get('id')),String(data.get('status'))); revalidatePath('/admin');
}
