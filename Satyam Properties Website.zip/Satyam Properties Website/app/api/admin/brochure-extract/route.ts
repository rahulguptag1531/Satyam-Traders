import { getChatGPTUser } from '../../../chatgpt-auth';
import { extractText } from 'unpdf';
import { parseBrochureText } from '../../../lib/brochure-parser';

export async function POST(request:Request) {
  const user=await getChatGPTUser();
  const allowed=process.env.ADMIN_EMAIL?.trim().toLowerCase();
  if (!user || !allowed || user.email.toLowerCase()!==allowed) return Response.json({error:'Unauthorized'},{status:403});
  const data=await request.formData();
  const file=data.get('brochure');
  if (!(file instanceof File) || file.type!=='application/pdf') return Response.json({error:'Choose a valid PDF brochure.'},{status:400});
  if (file.size>15*1024*1024) return Response.json({error:'The PDF must be smaller than 15 MB.'},{status:400});
  try {
    const result=await extractText(new Uint8Array(await file.arrayBuffer()),{mergePages:true});
    return Response.json(parseBrochureText(String(result.text||''),result.totalPages));
  } catch (error) {
    console.error('[brochure-extract] failed',error);
    return Response.json({error:'This PDF could not be read. Scanned-image brochures may need manual details.'},{status:422});
  }
}
