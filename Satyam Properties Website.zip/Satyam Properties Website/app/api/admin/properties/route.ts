import { getChatGPTUser } from '../../../chatgpt-auth';
import { saveProperty } from '../../../../db';
import { env } from 'cloudflare:workers';

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  const allowed = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  if (!user || !allowed || user.email.toLowerCase() !== allowed) return new Response('Unauthorized', { status: 403 });
  try {
    const data = await request.formData();
    const value = (key:string) => String(data.get(key) || '').trim();
    const title = value('title');
    const slug = (value('slug') || title).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'');
    if (!title || !slug || !value('location') || !value('size') || !value('price') || !value('note')) return new Response('Missing required property details', { status: 400 });
    let brochureUrl = value('existingBrochure');
    const brochure = data.get('brochure');
    if (brochure instanceof File && brochure.size > 0) {
      const extensions:Record<string,string>={'application/pdf':'pdf','image/jpeg':'jpg','image/png':'png','image/webp':'webp'};
      const extension=extensions[brochure.type];
      if (!extension) return new Response('Brochure must be a PDF, JPG, PNG, or WebP file', { status: 400 });
      if (brochure.size > 15 * 1024 * 1024) return new Response('Brochure file must be smaller than 15 MB', { status: 400 });
      const key = `brochures/${slug}-${Date.now()}.${extension}`;
      await env.BUCKET.put(key, await brochure.arrayBuffer(), { httpMetadata: { contentType: brochure.type, contentDisposition: `inline; filename="${slug}-brochure.${extension}"` } });
      brochureUrl = `/api/brochures/${key}`;
    }
    await saveProperty({slug,title,type:value('type'),location:value('location'),size:value('size'),price:value('price'),note:value('note'),image:value('image')||'/demo-wathoda-plot.webp',highlights:value('highlights').split(',').map(item=>item.trim()).filter(Boolean),status:value('status')||'live',brochureUrl});
    return Response.redirect(new URL(`/admin?edit=${encodeURIComponent(slug)}&saved=1#property-editor`, request.url), 303);
  } catch (error) {
    console.error('[admin/properties] save failed', error);
    return new Response('Could not save property changes', { status: 500 });
  }
}
