import { env } from 'cloudflare:workers';

export async function GET(_request:Request,{params}:{params:Promise<{key:string[]}>}) {
  const {key}=await params;
  const object=await env.BUCKET.get(key.join('/'));
  if (!object) return new Response('Brochure not found',{status:404});
  const headers=new Headers();
  object.writeHttpMetadata(headers);
  headers.set('etag',object.httpEtag);
  headers.set('cache-control','public, max-age=3600');
  return new Response(object.body,{headers});
}
