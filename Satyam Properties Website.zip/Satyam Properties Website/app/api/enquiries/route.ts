import { createEnquiry } from '../../../db';

export async function POST(request: Request) {
  const body = await request.json().catch(() => null) as Record<string, unknown> | null;
  const name=String(body?.name||'').trim(), phone=String(body?.phone||'').trim(), interest=String(body?.interest||'').trim(), budget=String(body?.budget||'').trim();
  if (!name || !interest || !budget || !/^[0-9 +()-]{10,16}$/.test(phone)) return Response.json({error:'Please enter valid details.'},{status:400});
  const id=await createEnquiry({name,phone,interest,budget,visitDate:String(body?.visitDate||'')});
  return Response.json({ok:true,id},{status:201});
}
