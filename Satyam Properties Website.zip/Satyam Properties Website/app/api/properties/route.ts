import { listProperties } from '../../../db';
export async function GET() { return Response.json(await listProperties()); }
