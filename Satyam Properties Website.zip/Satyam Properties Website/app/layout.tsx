import type { Metadata } from 'next';
import './globals.css';
import './extra.css';

export const metadata: Metadata = {
  title: 'Satyam Properties | Property • Investment • Trust',
  description: 'Trusted property guidance for plots, land and investment opportunities in Wathoda, Nagpur and nearby areas.',
  openGraph: {
    title: 'Satyam Properties | Property • Investment • Trust',
    description: 'Trusted local property guidance in Wathoda, Nagpur and nearby areas.',
    images: [{ url: 'https://satyam-properties-nagpur.thakurranveer2004.chatgpt.site/og.png', width: 1733, height: 907, alt: 'Satyam Properties — Property • Investment • Trust' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Satyam Properties | Property • Investment • Trust',
    description: 'Trusted local property guidance in Wathoda, Nagpur and nearby areas.',
    images: ['https://satyam-properties-nagpur.thakurranveer2004.chatgpt.site/og.png'],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
