export function parseBrochureText(text:string,pages=1) {
  const clean=text.replace(/\u0000/g,' ');
  const lines=[...new Set(clean.split(/\r?\n/).map(line=>line.replace(/\s+/g,' ').trim()).filter(line=>line.length>=3&&line.length<=150))];
  const lower=clean.toLowerCase();
  const type=/\b(flat|apartment|bhk|residency|tower)\b/.test(lower)?'Flats':/\b(layout|plot)\b/.test(lower)?'Plots & layouts':/\bland\b/.test(lower)?'Land':'Investment';
  const title=lines.find(line=>/\b(layout|residency|residences|apartment|tower|project|plot|flat|estate|heights)\b/i.test(line)&&!/brochure|satyam properties/i.test(line))||lines.find(line=>!/mobile|phone|email|www\.|brochure/i.test(line))||'New Property';
  const location=lines.find(line=>/\b(nagpur|wathoda|road|layout|wardha|umred|hingna|kamptee|besa|manish nagar)\b/i.test(line)&&line!==title)||'';
  const sizeMatches=clean.match(/(?:\b[1-6]\s*BHK\b|\b[\d,]+(?:\.\d+)?\s*(?:sq\.?\s*ft\.?|sqft|square feet|acres?)\b)/gi)||[];
  const price=clean.match(/(?:₹|Rs\.?|INR)\s*[\d,.]+\s*(?:Lakh|Lac|Crore|Cr)?/i)?.[0]||'';
  const amenityMap=[['Lift','lift'],['Parking','parking'],['Security','security'],['Garden','garden'],['Clubhouse','club'],['Gym','gym'],['Road access','road'],['Corner options','corner'],['RERA registered','rera'],['Ready to move','ready to move'],['East-facing','east facing']];
  const highlights=amenityMap.filter(([,term])=>lower.includes(term)).map(([label])=>label).slice(0,6);
  const note=lines.filter(line=>line!==title&&line!==location&&!/mobile|phone|email|www\./i.test(line)).slice(0,2).join(' ').slice(0,280);
  return {title,type,location,size:[...new Set(sizeMatches)].slice(0,3).join(' · '),price,note,highlights:highlights.join(', '),pages};
}
