'use client';

import { useEffect, useState } from 'react';
import { properties, type Property } from './data';

const Arrow = () => <span aria-hidden="true">↗</span>;
const WhatsApp = () => <span className="wa-icon" aria-hidden="true">●</span>;
const Logo = ({ compact = false }: { compact?: boolean }) => <img className={compact ? 'logo compact' : 'logo'} src="/satyam-properties-logo.png" alt="Satyam Properties" />;
const wa = 'https://wa.me/919370205689?text=Hello%20Satyam%20Properties%2C%20I%27m%20interested%20in%20a%20property.';

export default function Home() {
  const [filter, setFilter] = useState('All');
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [inventory, setInventory] = useState<Property[]>(properties);
  const [menuOpen, setMenuOpen] = useState(false);
  function smoothScroll(event: React.MouseEvent<HTMLAnchorElement>, sectionId: string) {
    event.preventDefault();
    setMenuOpen(false);
    const section = document.getElementById(sectionId);
    if (!section) return;
    const start = window.scrollY;
    const target = section.getBoundingClientRect().top + start - 96;
    const distance = target - start;
    const duration = Math.min(1100, Math.max(700, Math.abs(distance) * 0.38));
    const startedAt = performance.now();
    const ease = (progress: number) => progress < 0.5
      ? 4 * progress * progress * progress
      : 1 - Math.pow(-2 * progress + 2, 3) / 2;
    const animate = (now: number) => {
      const progress = Math.min((now - startedAt) / duration, 1);
      window.scrollTo(0, start + distance * ease(progress));
      if (progress < 1) requestAnimationFrame(animate);
    };
    requestAnimationFrame(animate);
    window.history.replaceState(null, '', `#${sectionId}`);
  }
  useEffect(() => { fetch('/api/properties').then(r => r.ok ? r.json() : null).then(data => Array.isArray(data) && setInventory(data)).catch(() => {}); }, []);
  const shown = filter === 'All' ? inventory : inventory.filter((property) => property.type === filter);
  async function handleEnquiry(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setSending(true); setSubmitError('');
    const form = new FormData(event.currentTarget);
    const response = await fetch('/api/enquiries',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:form.get('name'),phone:form.get('phone'),interest:form.get('interest'),budget:form.get('budget'),visitDate:form.get('date')})}).catch(()=>null);
    setSending(false); if (!response?.ok) { setSubmitError('Could not save your enquiry. Please call or WhatsApp us.'); return; } setSent(true);
  }

  return (
    <main>
      <div className="demo-strip"><span>Live MVP</span> Demo inventory — verify price and availability with our team</div>
      <nav className="nav" aria-label="Main navigation">
        <a className="brand" href="#top" aria-label="Satyam Properties home">
          <Logo />
        </a>
        <div className={`nav-links ${menuOpen ? 'open' : ''}`}>
          <a href="#properties" onClick={(event) => smoothScroll(event, 'properties')}>Properties</a>
          <a href="#services" onClick={(event) => smoothScroll(event, 'services')}>Services</a>
          <a href="#about" onClick={(event) => smoothScroll(event, 'about')}>Why us</a>
          <a href="#visit" onClick={(event) => smoothScroll(event, 'visit')}>Contact</a>
        </div>
        <div className="nav-actions">
          <a className="nav-phone" href="tel:+919370205689">93702 05689</a>
          <a className="nav-cta" href={wa} target="_blank" rel="noreferrer"><WhatsApp /> WhatsApp</a>
          <button className="menu-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation" aria-expanded={menuOpen}>{menuOpen ? '×' : '☰'}</button>
        </div>
      </nav>

      <section className="hero" id="top">
        <div className="hero-copy">
          <div className="hero-kicker"><span className="verified-dot">✓</span> Trusted in Nagpur for 10+ years</div>
          <p className="eyebrow">Wathoda · Nagpur · Nearby areas</p>
          <h1>Find land that<br /><em>moves you forward.</em></h1>
          <p className="lede">Residential plots, land parcels and investment opportunities—shortlisted with local insight and explained with complete clarity.</p>
          <div className="hero-actions">
            <a className="primary" href="#properties">Browse properties <Arrow /></a>
            <a className="secondary" href="#visit">Schedule a free site visit</a>
          </div>
          <div className="hero-proof">
            <div><strong>10+</strong><span>Years of local experience</span></div>
            <div><strong>1:1</strong><span>Personal property guidance</span></div>
            <div><strong>100%</strong><span>Direct human support</span></div>
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-image" aria-hidden="true"></div><div className="hero-shade" aria-hidden="true"></div>
          <div className="location-chip"><span>⌖</span><div><small>Serving</small><strong>Wathoda · Nagpur</strong></div></div>
          <div className="hero-status"><span></span> Site visits open this week</div>
          <a className="floating-card" href="/properties/wathoda-residential-plot">
            <div className="card-top"><span className="tag">Featured · Demo</span><span>Wathoda, Nagpur</span></div>
            <h2>Wathoda Residential Plot</h2>
            <p>1,500 sq.ft · East facing · Road access</p>
            <div><strong>₹22.5 Lakh*</strong><span className="round-arrow"><Arrow /></span></div>
          </a>
        </div>
      </section>

      <section className="quick-search" id="services" aria-label="Property categories">
        <div className="quick-title"><span>Explore by need</span><strong>What are you looking for?</strong></div>
        {[['Plots & layouts', 'Residential plots', 'From 1,000 sq.ft'], ['Flats', 'Flats for sale', 'Homes in Nagpur'], ['Land', 'Land parcels', 'For development']].map(([type, title, subtitle]) => (
          <a href="#properties" key={type} onClick={() => setFilter(type)}><span className="quick-icon">⌂</span><div><strong>{title}</strong><small>{subtitle}</small></div><Arrow /></a>
        ))}
      </section>

      <section className="properties" id="properties">
        <div className="section-head"><div><p className="eyebrow">Curated opportunities</p><h2>A smarter property shortlist.</h2></div><div className="section-intro"><p>Explore illustrative opportunities across Wathoda, Nagpur and nearby growth areas. Our team verifies live inventory before every site visit.</p><a href={wa} target="_blank" rel="noreferrer">Tell us your requirement →</a></div></div>
        <div className="filters" role="group" aria-label="Filter properties">{['All', 'Plots & layouts', 'Flats', 'Land', 'Investment'].map((item) => <button className={filter === item ? 'active' : ''} onClick={() => setFilter(item)} key={item}>{item}{item === 'All' && <span>{inventory.length}</span>}</button>)}</div>
        <div className="property-grid">{shown.map((property, index) => (
          <a href={`/properties/${property.slug}`} className="property-card" key={property.slug}>
            <div className="card-art"><img src={property.image} alt={`Illustrative demo view for ${property.title}`} /><span className="card-number">0{index + 1}</span><span className="demo-pill">Demo image</span><div className="image-shade"></div></div>
            <div className="card-copy"><span className="tag">{property.type}</span><h3>{property.title}</h3><p><span>⌖</span> {property.location}</p><div className="property-meta"><span>{property.size}</span><span>Site visit available</span></div><div className="card-price"><strong>{property.price}</strong><span className="round-arrow"><Arrow /></span></div></div>
          </a>
        ))}</div>
      </section>

      <section className="journey" aria-label="How Satyam Properties works">
        <div className="journey-heading"><p className="eyebrow">Simple by design</p><h2>From requirement<br />to the right site.</h2></div>
        <div className="journey-steps">{[['01', 'Share your requirement', 'Tell us your preferred area, budget and purpose.'], ['02', 'Get a focused shortlist', 'We narrow the options using practical local insight.'], ['03', 'Visit with confidence', 'We coordinate the site visit and guide your next steps.']].map(([number, title, copy]) => <div key={number}><span>{number}</span><div className="step-line"></div><h3>{title}</h3><p>{copy}</p></div>)}</div>
      </section>

      <section className="split" id="about"><div className="principles"><p className="eyebrow">Property • Investment • Trust</p><h2>Local knowledge.<br />Straight answers.</h2><p>From the first shortlist to site visit and documentation guidance, Satyam Properties helps buyers make grounded decisions without the noise.</p><div className="signature"><Logo compact /><div><strong>Satyam Properties</strong><small>Wathoda, Nagpur</small></div></div></div><div className="service-list">{[['01', 'Residential plots & layouts', 'Find plots suited to your budget and use.'], ['02', 'Land parcels', 'Explore larger opportunities with local context.'], ['03', 'Investment opportunities', 'Understand location potential before you decide.'], ['04', 'End-to-end guidance', 'Shortlisting, visits and documentation support.']].map(([number, title, copy]) => <div key={number}><span>{number}</span><div><strong>{title}</strong><small>{copy}</small></div><Arrow /></div>)}</div></section>

      <section className="visit" id="visit"><div className="visit-copy"><p className="eyebrow">Let’s talk property</p><h2>Your next site visit starts here.</h2><p>Share your requirement and preferred date. We’ll call to confirm the property, timing and meeting point.</p><div className="contact-cards"><a href="tel:+919370205689"><span>Call us</span><strong>+91 93702 05689</strong></a><div><span>Visit us</span><strong>33, Saraswatinagar<br />Wathoda Layout, Nagpur</strong></div></div></div><form onSubmit={handleEnquiry}>{sent ? <div className="success"><span>✓</span><h3>Enquiry received.</h3><p>Your details are safely recorded. Our team will call you to confirm the next step.</p><a className="primary" href={wa} target="_blank" rel="noreferrer">Continue on WhatsApp <Arrow /></a><button type="button" onClick={() => setSent(false)}>Send another enquiry</button></div> : <><div className="form-title"><span>Free consultation</span><strong>Tell us what you need</strong></div><label>Name<input required name="name" placeholder="Your full name" /></label><label>Phone<input required name="phone" inputMode="tel" pattern="[0-9 +()-]{10,16}" placeholder="Mobile number" /></label><div className="form-row"><label>Looking for<select name="interest"><option>Residential plot</option><option>Land parcel</option><option>Investment property</option><option>Other property</option></select></label><label>Budget<select name="budget"><option>Under ₹20L</option><option>₹20L – ₹40L</option><option>₹40L – ₹75L</option><option>₹75L+</option></select></label></div><label>Preferred visit date<input type="date" name="date" /></label><button disabled={sending} className="primary submit">{sending ? 'Saving enquiry…' : 'Request a call back'} <Arrow /></button>{submitError && <small className="form-error">{submitError}</small>}<small>Your details are used only to contact you about your property requirement.</small></>}</form></section>

      <footer id="contact"><div className="footer-brand"><div className="brand inverse"><Logo /></div><p>Property • Investment • Trust</p></div><div className="footer-links"><strong>Explore</strong><a href="#properties">Properties</a><a href="#about">Why us</a><a href="#visit">Book a visit</a></div><div className="footer-contact"><strong>Contact</strong><a href="tel:+919370205689">+91 93702 05689</a><a href={wa} target="_blank" rel="noreferrer">WhatsApp ↗</a><span>Wathoda, Nagpur</span></div><small>© 2026 Satyam Properties · Demo inventory is for MVP presentation only.</small></footer>
      <div className="mobile-bar"><a href="tel:+919370205689">Call now</a><a href={wa} target="_blank" rel="noreferrer"><WhatsApp /> WhatsApp</a></div>
    </main>
  );
}
