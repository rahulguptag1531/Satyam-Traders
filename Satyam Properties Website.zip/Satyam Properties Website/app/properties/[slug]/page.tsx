import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { getProperty } from '../../../db';
export const dynamic = 'force-dynamic';

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const property = await getProperty(slug);
  return property ? {
    title: `${property.title} | Satyam Properties`,
    description: `Demo listing: ${property.note} Contact Satyam Properties to verify availability.`,
    openGraph: { title: property.title, description: property.note, images: [] },
    twitter: { card: 'summary', title: property.title, description: property.note, images: [] },
  } : {};
}

export default async function PropertyPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const property = await getProperty(slug);
  if (!property) notFound();
  const message = encodeURIComponent(`Hello Satyam Properties, I'm interested in the demo listing: ${property.title}. Please share current details.`);

  return <main className="detail">
    <nav className="nav"><a className="brand" href="/"><img className="logo" src="/satyam-properties-logo.png" alt="Satyam Properties" /></a><a className="nav-cta" href={`https://wa.me/919370205689?text=${message}`} target="_blank">Ask on WhatsApp ↗</a></nav>
    <div className="detail-grid">
      <div className="detail-art"><img src={property.image} alt={`Illustrative demo view for ${property.title}`} /><div className="detail-image-shade"></div><span>DEMO IMAGE · NOT ACTUAL INVENTORY</span></div>
      <div className="detail-copy"><a href="/#properties" className="back">← All properties</a><p className="eyebrow">{property.type} · {property.location}</p><h1>{property.title}</h1><p className="detail-note">{property.note}</p><div className="facts"><div><span>Indicative price</span><strong>{property.price}</strong></div><div><span>Plot / parcel size</span><strong>{property.size}</strong></div></div><h2>Property highlights</h2><ul>{property.highlights.map(item => <li key={item}>{item}</li>)}</ul>{property.brochureUrl&&<a className="brochure-link" href={property.brochureUrl} target="_blank" rel="noreferrer"><span>PDF</span><div><strong>View property brochure</strong><small>Open layout and project details ↗</small></div></a>}<div className="demo-notice"><strong>Demo property</strong><p>This listing uses illustrative information. Call Satyam Properties to confirm real inventory, title status, price and availability.</p></div><div className="detail-actions"><a className="primary" href={`https://wa.me/919370205689?text=${message}`} target="_blank">Enquire on WhatsApp ↗</a><a className="outline" href="/#visit">Book a site visit</a></div></div>
    </div>
  </main>;
}
