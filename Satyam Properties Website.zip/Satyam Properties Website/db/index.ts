import { env } from 'cloudflare:workers';
import { properties as demoProperties, type Property } from '../app/data';

type EnquiryInput = { name:string; phone:string; interest:string; budget:string; visitDate?:string };

async function ready() {
  await env.DB.batch([
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS enquiries (id TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL, interest TEXT NOT NULL, budget TEXT NOT NULL, visit_date TEXT, status TEXT NOT NULL DEFAULT 'new', source TEXT NOT NULL DEFAULT 'website', created_at TEXT NOT NULL)`),
    env.DB.prepare(`CREATE INDEX IF NOT EXISTS enquiries_created_idx ON enquiries(created_at DESC)`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS properties (id TEXT PRIMARY KEY, slug TEXT NOT NULL UNIQUE, title TEXT NOT NULL, type TEXT NOT NULL, location TEXT NOT NULL, size TEXT NOT NULL, price TEXT NOT NULL, note TEXT NOT NULL, image TEXT NOT NULL, highlights TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'demo', updated_at TEXT NOT NULL)`),
  ]);
  const columns = await env.DB.prepare(`PRAGMA table_info(properties)`).all();
  if (!columns.results.some((column) => column.name === 'brochure_url')) await env.DB.prepare(`ALTER TABLE properties ADD COLUMN brochure_url TEXT`).run();
  const now = new Date().toISOString();
  await env.DB.batch(demoProperties.map((p) => env.DB.prepare(`INSERT OR IGNORE INTO properties (id,slug,title,type,location,size,price,note,image,highlights,status,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).bind(crypto.randomUUID(),p.slug,p.title,p.type,p.location,p.size,p.price,p.note,p.image,JSON.stringify(p.highlights),'demo',now)));
}

function mapProperty(row: Record<string, unknown>): Property {
  return { slug:String(row.slug), title:String(row.title), type:String(row.type), location:String(row.location), size:String(row.size), price:String(row.price), note:String(row.note), image:String(row.image), color:'#71806d', highlights:JSON.parse(String(row.highlights || '[]')), status:String(row.status || 'live'), brochureUrl:row.brochure_url ? String(row.brochure_url) : undefined };
}

export async function listProperties() { await ready(); const result = await env.DB.prepare(`SELECT * FROM properties ORDER BY updated_at DESC`).all(); return result.results.map((r) => mapProperty(r)); }
export async function getProperty(slug:string) { await ready(); const row = await env.DB.prepare(`SELECT * FROM properties WHERE slug = ?`).bind(slug).first(); return row ? mapProperty(row) : null; }
export async function createEnquiry(input:EnquiryInput) { await ready(); const id=crypto.randomUUID(); await env.DB.prepare(`INSERT INTO enquiries (id,name,phone,interest,budget,visit_date,status,source,created_at) VALUES (?,?,?,?,?,?,?,?,?)`).bind(id,input.name,input.phone,input.interest,input.budget,input.visitDate || null,'new','website',new Date().toISOString()).run(); return id; }
export async function listEnquiries() { await ready(); const result=await env.DB.prepare(`SELECT * FROM enquiries ORDER BY created_at DESC`).all(); return result.results; }
export async function updateEnquiryStatus(id:string,status:string) { await ready(); await env.DB.prepare(`UPDATE enquiries SET status=? WHERE id=?`).bind(status,id).run(); }
export async function saveProperty(input:Omit<Property,'color'|'featured'> & {status?:string}) { await ready(); const now=new Date().toISOString(); await env.DB.prepare(`INSERT INTO properties (id,slug,title,type,location,size,price,note,image,highlights,status,brochure_url,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(slug) DO UPDATE SET title=excluded.title,type=excluded.type,location=excluded.location,size=excluded.size,price=excluded.price,note=excluded.note,image=excluded.image,highlights=excluded.highlights,status=excluded.status,brochure_url=excluded.brochure_url,updated_at=excluded.updated_at`).bind(crypto.randomUUID(),input.slug,input.title,input.type,input.location,input.size,input.price,input.note,input.image,JSON.stringify(input.highlights),input.status || 'live',input.brochureUrl || null,now).run(); }
