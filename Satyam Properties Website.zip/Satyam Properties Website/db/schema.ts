import { sqliteTable, text } from 'drizzle-orm/sqlite-core';

export const enquiries = sqliteTable('enquiries', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  phone: text('phone').notNull(),
  interest: text('interest').notNull(),
  budget: text('budget').notNull(),
  visitDate: text('visit_date'),
  status: text('status').notNull().default('new'),
  source: text('source').notNull().default('website'),
  createdAt: text('created_at').notNull(),
});

export const managedProperties = sqliteTable('properties', {
  id: text('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  title: text('title').notNull(),
  type: text('type').notNull(),
  location: text('location').notNull(),
  size: text('size').notNull(),
  price: text('price').notNull(),
  note: text('note').notNull(),
  image: text('image').notNull(),
  highlights: text('highlights').notNull(),
  status: text('status').notNull().default('demo'),
  brochureUrl: text('brochure_url'),
  updatedAt: text('updated_at').notNull(),
});
