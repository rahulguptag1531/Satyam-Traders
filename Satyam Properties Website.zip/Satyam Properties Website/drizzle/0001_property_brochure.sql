ALTER TABLE `properties` ADD `brochure_url` text;
